import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
MASTER_PASSWORD: str = os.getenv("MASTER_PASSWORD", "usta2024")  # Ustalar kirish uchun parol

if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN .env faylida belgilanmagan!")
