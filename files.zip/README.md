# 🏗 Qurilish Nazorat Boti

## 📁 Fayl strukturasi
```
qurilish_bot/
├── main.py                  # Ishga tushirish
├── config.py                # Token, parol
├── db.py                    # SQLite (6 jadval)
├── keyboards.py             # Barcha klaviaturalar
├── Dockerfile               # Docker image
├── docker-compose.yml       # VPS deploy
├── railway.toml             # Railway deploy
├── requirements.txt
├── .env                     # (gitga yuklanmaydi)
├── .gitignore
└── handlers/
    ├── common.py            # /start, rol tanlash
    ├── master.py            # Usta: obyekt, xarajat, hisobot
    ├── client.py            # Mijoz: ko'rish, cheklar
    ├── stats.py             # Statistika + byudjet limiti
    └── chat.py              # Usta↔Mijoz chat
```

## 🚀 Mahalliy ishga tushirish
```bash
pip install -r requirements.txt
cp .env.example .env
# .env ga BOT_TOKEN kiriting
python main.py
```

## 🚂 Railway orqali deploy (TAVSIYA ETILADI — bepul)
1. https://railway.app — GitHub bilan kiring
2. "New Project" → "Deploy from GitHub repo"
3. Reponi tanlang
4. "Variables" bo'limida qo'shing:
   - BOT_TOKEN = sizning_tokeningiz
   - MASTER_PASSWORD = xohlagan_parol
5. Deploy tugmasini bosing ✅

## 🖥️ VPS orqali deploy (Docker bilan)
```bash
git clone <repo_url>
cd qurilish_bot
cp .env.example .env
nano .env        # BOT_TOKEN va MASTER_PASSWORD kiriting
docker-compose up -d
docker-compose logs -f   # loglarni ko'rish
```

## 🗄️ Jadvallar
| Jadval | Vazifasi |
|---|---|
| users | Foydalanuvchilar (usta/mijoz) |
| projects | Loyihalar + byudjet limiti |
| project_clients | Ulanishlar |
| expenses | Xarajatlar + chek rasmlari |
| reports | Kunlik hisobotlar |
| messages | Chat xabarlari |
